#Esse arquivo vai ser basicamente a porta de entrada pro código, tendo navegação, interface etc.

from dados import tarefas, fila_pendente, pilha_concluida, prioridades, status
from utils import titulo
from tarefas import cadastrar_livro, listar_livros, atualizar_status, ver_historico_concluidos



def mostrar_menu():
    titulo("Biblioteca Pessoal")  # usa a função do módulo utils.py
    print("1. Adicionar Livros")
    print("2. Listar Livros") #Mostra os livros guardados pela função "append"
    print("3. Atualizar Status")
    print("4. Histórico de Livros concluidos")
    print("5. Sair")


while True:
    mostrar_menu () #chama o menu em vez de se repetir a cada input

    opcao = input("Escolha uma opção: ")
    if opcao == "1":
        cadastrar_livro()
    
    elif opcao == "2":
        listar_livros()
    
    elif opcao == "3":
        atualizar_status()

    elif opcao == "4":
        ver_historico_concluidos()

    elif opcao == "5":
        print("Saindo...")
        break
    else:
        print("Opção inválida. Tente novamente.")