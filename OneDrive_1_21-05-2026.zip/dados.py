#Esse arquivo temm de propósito guardar as variaveis globais (listas, filas, tuplas, pilha) (dados globais)

#Dados guardados no projeto

tarefas = [] #Isso daqui basaicamente vai guardar tudo, como: livro | não modifiquei o nome para não causar tanta confusão no código, muitos "livros" ficaria confuso demais
fila_pendente = [] #fila (FIFO): tarefas pendentes (imagino que isso guarde os livros registrados para utilizar depois, como colocar ele no "Em andamento")
pilha_concluida = [] #pilha (LIFO): tarefas concluídas
em_andamento = [] #lista: tarefas em andamento


prioridades = ("Baixa", "Média", "Alta")
status      = ("Pendente", "Em Andamento", "Concluída")