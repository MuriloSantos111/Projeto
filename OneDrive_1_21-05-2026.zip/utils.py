#Isso aqui vai ser uma pasta de apoio para as outras basicamente, ela serve como uma pasta para códigos que vão ser reutilizados pelas outras

def linha():
    print("=" * 40)

def titulo(texto):
    linha()
    print(texto.center(40))
    linha()