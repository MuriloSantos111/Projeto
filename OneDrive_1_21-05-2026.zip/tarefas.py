#Esse arquivo serve como as regras do negócio, ele: cadastra, lista e atualiza oq tem aqui.
from dados import tarefas, prioridades, status, fila_pendente, pilha_concluida
from utils import titulo

#essa linha principal de codigo funciona pra 
def cadastrar_livro():
    titulo("Cadastrar Livro")

    Titulo = input("Titulo: ")
    autor = input("Autor: ")
    ano = input("Ano: ")
    genero = input("Gênero: ") 

    print(' - Prioridades: 1. Baixa | 2. Média | 3. Alta')
    opcao = input("Prioridade: ")

    # essa linha de código vê a prioridade da tupla com base no índice, ex: [1] = Média.
    if opcao == "1":
        prioridade = prioridades[0]  # "Baixa"
    elif opcao == "2":
        prioridade = prioridades[1]  # "Média"
    else:
        prioridade = prioridades[2]  # "Alta"

    dict_livro = {
        "id":      len(tarefas) + 1,
        "titulo":      Titulo, # "T" está maiusculo para evitar dar problemas com outros "titulos" parecidos 
        "autor":       autor,
        "ano":         ano,
        'genero':      genero,
        "prioridade":  prioridade,
        "status":      status[0]
        }
    
    tarefas.append(dict_livro)
    fila_pendente.append(dict_livro)


    print("Livro registrado com sucesso!!")

#Toda essa linha de código em cima funciona para cadastrar os livros e atribuir eles ao código


def listar_livros():
    titulo("Listar Livros")

    for i, tarefa in enumerate(tarefas, start=1):
        print(f'TAREFA: {i}')
        print(f"Título: {tarefa['titulo']}")
        print(f"ID: {tarefa['id']}") #eu não ia colocar essa linha, mas depois de uns testes eu percebi que o codigo guarda os livros por ID, mas não mostra o ID pro usuario, ai fica dificl saber qual livro vc quer pesquisar
        print(f"Autor: {tarefa['autor']}")
        print(f"Ano: {tarefa['ano']}")
        print(f"Gênero: {tarefa['genero']}")
        print(f"Prioridade: {tarefa['prioridade']}")
        print(f"Status: {tarefa['status']}")
        print()  # linha em branco entre tarefas

#a linha de cima basicamente mostra as caracteristicas do livro e oq tem dentro dele, como: Título, Autor etc.


#aqui a gente tá modificando o Status de um Livro já existente no guardado no código 
def atualizar_status():
    print("\n--- Atualizar Status ---")
    listar_livros()


    #Isso mostra caso a não tenha NENHUM livro na lista
    if len(tarefas) == 0:
        return
    
    #esse codigo é rodado quando aparece livros na lista
    try:
        id_livro = int(input("Digite o ID do livro: "))
    except ValueError:
        print("Digite um número válido.")
        return

    for livro in tarefas:
        if livro["id"] == id_livro:
            print("\nEscolha o novo status:")
            print("1 - A Ler")
            print("2 - Lendo")
            print("3 - Concluído")
            opcao = input("Opção: ")

            if opcao == "1":
                livro["status"] = status[0]

                if livro not in fila_pendente:
                    fila_pendente.append(livro)

            elif opcao == "2":
                livro["status"] = status[1]

            elif opcao == "3":
                livro["status"] = status[2]

                pilha_concluida.append(livro)   # empilha!

                if livro in fila_pendente:
                    fila_pendente.remove(livro)  # sai da fila

            print("Status atualizado com sucesso!")
            return
    
    print("Livro não encontrado.")

#o codigo de cima funciona como: O usuario vai atualizar o status do livro, não especifiquei mas a ordem do "ID" dos livros é marcada pela ordem que eu adicionei eles, como: Dom casmurro = 1, Iracema = 2 etc.

#Já esse código é apenas para mostrar o historico dos Livros cujo os status tem "Concluido"
def ver_historico_concluidos():
    titulo("Histórico de Tarefas Concluídas")
    if len(pilha_concluida) == 0:
        print("Nenhuma tarefa concluída.")
        return
    
    for i, tarefa in enumerate(reversed(pilha_concluida), start=1):
        print(f'LIVROS CONCLUÍDOS: {i}')
        print(f"ID: {tarefa['id']}")
        print(f"Título: {tarefa['titulo']}")
        print(f"Autor: {tarefa['autor']}")
        print(f"Gênero: {tarefa['genero']}")
        print(f"Prioridade: {tarefa['prioridade']}")
        print(f"Status: {tarefa['status']}")
        print()